package com.igreja.multitrack

import org.json.JSONArray
import org.json.JSONObject
import java.io.File

data class TrackInfo(
    var name: String,
    val file: String,
    var guide: Boolean,
    var volume: Float = 1f
)

data class Song(
    val id: String,
    var name: String,
    val tracks: MutableList<TrackInfo> = mutableListOf()
)

/** Guarda as músicas importadas (arquivos de áudio + configurações) dentro do app. */
class Library(private val root: File) {

    val songs = mutableListOf<Song>()
    private val index = File(root, "library.json")

    init {
        root.mkdirs()
        load()
    }

    fun songDir(song: Song): File = File(root, "songs/${song.id}")

    private fun load() {
        songs.clear()
        if (!index.exists()) return
        try {
            val arr = JSONArray(index.readText())
            for (i in 0 until arr.length()) {
                val o = arr.getJSONObject(i)
                val song = Song(o.getString("id"), o.getString("name"))
                val ts = o.getJSONArray("tracks")
                for (j in 0 until ts.length()) {
                    val t = ts.getJSONObject(j)
                    song.tracks.add(
                        TrackInfo(
                            t.getString("name"),
                            t.getString("file"),
                            t.getBoolean("guide"),
                            t.optDouble("volume", 1.0).toFloat()
                        )
                    )
                }
                songs.add(song)
            }
        } catch (e: Exception) {
            // índice corrompido: começa vazio
        }
    }

    fun save() {
        val arr = JSONArray()
        for (s in songs) {
            val o = JSONObject()
            o.put("id", s.id)
            o.put("name", s.name)
            val ts = JSONArray()
            for (t in s.tracks) {
                val to = JSONObject()
                to.put("name", t.name)
                to.put("file", t.file)
                to.put("guide", t.guide)
                to.put("volume", t.volume.toDouble())
                ts.put(to)
            }
            o.put("tracks", ts)
            arr.put(o)
        }
        index.writeText(arr.toString())
    }

    fun delete(song: Song) {
        songDir(song).deleteRecursively()
        songs.remove(song)
        save()
    }
}
