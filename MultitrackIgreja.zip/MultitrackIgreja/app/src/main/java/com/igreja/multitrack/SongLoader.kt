package com.igreja.multitrack

import android.content.Context
import java.io.File
import java.util.concurrent.Callable
import java.util.concurrent.Executors
import java.util.concurrent.atomic.AtomicInteger

/** Decodifica as faixas de uma música (em paralelo) e prepara para tocar. */
object SongLoader {

    private const val MAX_CACHE_BYTES = 1_000_000_000L

    fun cacheDir(ctx: Context): File = File(ctx.cacheDir, "pcm").also { it.mkdirs() }

    fun clearCache(ctx: Context, song: Song) {
        cacheDir(ctx).listFiles()?.filter { it.name.startsWith(song.id + "_") }?.forEach { it.delete() }
    }

    private fun prune(dir: File, keepPrefix: String) {
        val files = dir.listFiles() ?: return
        var total = files.sumOf { it.length() }
        if (total <= MAX_CACHE_BYTES) return
        for (f in files.filter { !it.name.startsWith(keepPrefix) }.sortedBy { it.lastModified() }) {
            total -= f.length()
            f.delete()
            if (total <= MAX_CACHE_BYTES) break
        }
    }

    fun load(
        ctx: Context,
        lib: Library,
        song: Song,
        progress: (done: Int, total: Int) -> Unit
    ): List<AudioEngine.Track> {
        val cache = cacheDir(ctx)
        prune(cache, song.id + "_")

        val src = lib.songDir(song)
        val total = song.tracks.size
        val done = AtomicInteger(0)
        val pool = Executors.newFixedThreadPool(3)
        try {
            val futures = song.tracks.mapIndexed { i, t ->
                pool.submit(Callable<File> {
                    val input = File(src, t.file)
                    val pcm = File(cache, "${song.id}_$i.pcm")
                    if (!pcm.exists() || pcm.lastModified() < input.lastModified()) {
                        TrackDecoder.decodeToMono(input, pcm)
                    } else {
                        pcm.setLastModified(System.currentTimeMillis())
                    }
                    progress(done.incrementAndGet(), total)
                    pcm
                })
            }
            val files = futures.map { it.get() }
            return song.tracks.mapIndexed { i, t ->
                AudioEngine.Track.fromFile(t.name, files[i], t.guide, t.volume)
            }
        } finally {
            pool.shutdown()
        }
    }
}
