package com.igreja.multitrack

import android.app.Activity
import android.app.AlertDialog
import android.content.Intent
import android.graphics.Color
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import android.net.Uri
import android.os.Bundle
import android.os.Handler
import android.os.Looper
import android.provider.OpenableColumns
import android.view.Gravity
import android.view.View
import android.view.ViewGroup
import android.view.WindowManager
import android.widget.Button
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.SeekBar
import android.widget.SeekBar.OnSeekBarChangeListener
import android.widget.Switch
import android.widget.TextView
import android.widget.Toast
import java.io.File

class MainActivity : Activity() {

    private companion object {
        const val REQ_PICK = 42
        const val MATCH = ViewGroup.LayoutParams.MATCH_PARENT
        const val WRAP = ViewGroup.LayoutParams.WRAP_CONTENT

        val BG = Color.parseColor("#121212")
        val SURFACE = Color.parseColor("#1E1E1E")
        val SURFACE2 = Color.parseColor("#2C2C2C")
        val MUTED = Color.parseColor("#9E9E9E")
        val ACCENT = Color.parseColor("#4FC3F7")
        val GREEN = Color.parseColor("#66BB6A")
        val YELLOW = Color.parseColor("#FFCA28")
        val ORANGE = Color.parseColor("#FFA726")
        val RED = Color.parseColor("#EF5350")
    }

    private lateinit var library: Library
    private lateinit var root: FrameLayout
    private val engine = AudioEngine()
    private val ui = Handler(Looper.getMainLooper())

    private var pendingName = ""
    private var inPlayer = false
    private var dragging = false
    private var playBtn: Button? = null
    private var seek: SeekBar? = null
    private var timeText: TextView? = null

    private val ticker = object : Runnable {
        override fun run() {
            updateTransport()
            if (inPlayer) ui.postDelayed(this, 150)
        }
    }

    // ---------------------------------------------------------------- ciclo de vida

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        library = Library(File(filesDir, "library"))
        root = FrameLayout(this)
        root.setBackgroundColor(BG)
        setContentView(root)
        engine.onEnded = { runOnUiThread { updateTransport() } }
        showList()
    }

    override fun onBackPressed() {
        if (inPlayer) leavePlayer() else super.onBackPressed()
    }

    override fun onDestroy() {
        ui.removeCallbacksAndMessages(null)
        engine.release()
        super.onDestroy()
    }

    // ---------------------------------------------------------------- helpers de interface

    private fun dp(v: Int): Int = (v * resources.displayMetrics.density).toInt()

    private fun bg(color: Int, radius: Int = 12): GradientDrawable {
        val d = GradientDrawable()
        d.setColor(color)
        d.cornerRadius = dp(radius).toFloat()
        return d
    }

    private fun label(s: String, size: Float = 16f, color: Int = Color.WHITE, bold: Boolean = false): TextView {
        val t = TextView(this)
        t.text = s
        t.textSize = size
        t.setTextColor(color)
        if (bold) t.setTypeface(null, Typeface.BOLD)
        return t
    }

    private fun button(
        s: String,
        color: Int = SURFACE2,
        textColor: Int = Color.WHITE,
        size: Float = 16f,
        onClick: () -> Unit
    ): Button {
        val b = Button(this)
        b.text = s
        b.setAllCaps(false)
        b.textSize = size
        b.setTextColor(textColor)
        b.background = bg(color)
        b.stateListAnimator = null
        b.setOnClickListener { onClick() }
        return b
    }

    private fun lp(w: Int, h: Int, top: Int = 0, weight: Float = 0f): LinearLayout.LayoutParams {
        val p = LinearLayout.LayoutParams(w, h, weight)
        p.topMargin = dp(top)
        return p
    }

    private fun vertical(): LinearLayout {
        val l = LinearLayout(this)
        l.orientation = LinearLayout.VERTICAL
        l.setPadding(dp(16), dp(14), dp(16), dp(24))
        return l
    }

    // ---------------------------------------------------------------- lista de músicas

    private fun showList() {
        inPlayer = false
        ui.removeCallbacks(ticker)
        window.clearFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        engine.pause()
        root.removeAllViews()

        val col = vertical()
        col.addView(label("Multitrack Igreja", 28f, bold = true))
        col.addView(label("Toque numa música para abrir. Segure para apagar.", 14f, MUTED))
        col.addView(button("＋  Nova música", ACCENT, Color.BLACK, 18f) { askName() }, lp(MATCH, dp(64), top = 16))

        if (library.songs.isEmpty()) {
            col.addView(
                label("Nenhuma música ainda. Toque em \"Nova música\" e escolha todos os arquivos (stems) dela de uma vez.", 15f, MUTED),
                lp(MATCH, WRAP, top = 24)
            )
        }

        for (song in library.songs) {
            val b = button("${song.name}   ·   ${song.tracks.size} faixas", SURFACE, Color.WHITE, 18f) { openSong(song) }
            b.gravity = Gravity.START or Gravity.CENTER_VERTICAL
            b.setPadding(dp(16), 0, dp(16), 0)
            b.setOnLongClickListener {
                confirmDelete(song)
                true
            }
            col.addView(b, lp(MATCH, dp(64), top = 10))
        }

        val scroll = ScrollView(this)
        scroll.addView(col)
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))
    }

    private fun confirmDelete(song: Song) {
        AlertDialog.Builder(this)
            .setTitle("Apagar \"${song.name}\"?")
            .setMessage("Os arquivos dessa música serão removidos do app.")
            .setPositiveButton("Apagar") { _, _ ->
                SongLoader.clearCache(this, song)
                library.delete(song)
                showList()
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    // ---------------------------------------------------------------- importar música

    private fun askName() {
        val input = EditText(this)
        input.hint = "Nome da música"
        input.setSingleLine()
        AlertDialog.Builder(this)
            .setTitle("Nova música")
            .setMessage("Digite o nome. Em seguida, selecione todos os arquivos de áudio (bateria, baixo, guia, click etc.) dessa música.")
            .setView(input)
            .setPositiveButton("Escolher arquivos") { _, _ ->
                pendingName = input.text.toString().trim().ifEmpty { "Música" }
                val i = Intent(Intent.ACTION_OPEN_DOCUMENT)
                i.addCategory(Intent.CATEGORY_OPENABLE)
                i.type = "audio/*"
                i.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true)
                startActivityForResult(i, REQ_PICK)
            }
            .setNegativeButton("Cancelar", null)
            .show()
    }

    override fun onActivityResult(requestCode: Int, resultCode: Int, data: Intent?) {
        super.onActivityResult(requestCode, resultCode, data)
        if (requestCode != REQ_PICK || resultCode != RESULT_OK || data == null) return
        val uris = mutableListOf<Uri>()
        val clip = data.clipData
        if (clip != null) {
            for (i in 0 until clip.itemCount) uris.add(clip.getItemAt(i).uri)
        } else {
            data.data?.let { uris.add(it) }
        }
        if (uris.isNotEmpty()) importSong(pendingName, uris)
    }

    private fun displayName(uri: Uri): String {
        contentResolver.query(uri, arrayOf(OpenableColumns.DISPLAY_NAME), null, null, null)?.use { c ->
            if (c.moveToFirst()) {
                val i = c.getColumnIndex(OpenableColumns.DISPLAY_NAME)
                if (i >= 0) return c.getString(i)
            }
        }
        return uri.lastPathSegment ?: "faixa"
    }

    private fun guessGuide(name: String): Boolean {
        val n = name.lowercase()
        return listOf("click", "clique", "guia", "guide", "cue", "metro", "count").any { n.contains(it) }
    }

    private fun importSong(name: String, uris: List<Uri>) {
        val dlg = AlertDialog.Builder(this)
            .setMessage("Importando ${uris.size} arquivos…")
            .setCancelable(false)
            .show()
        Thread {
            try {
                val song = Song(System.currentTimeMillis().toString(), name)
                val dir = library.songDir(song)
                dir.mkdirs()
                uris.forEachIndexed { i, uri ->
                    val display = displayName(uri)
                    val base = display.substringBeforeLast('.')
                    val ext = display.substringAfterLast('.', "mp3")
                    val f = File(dir, "$i.$ext")
                    contentResolver.openInputStream(uri)?.use { inp ->
                        f.outputStream().use { out -> inp.copyTo(out) }
                    }
                    song.tracks.add(TrackInfo(base, f.name, guessGuide(base)))
                }
                song.tracks.sortBy { it.name.lowercase() }
                library.songs.add(song)
                library.save()
                runOnUiThread {
                    dlg.dismiss()
                    showList()
                }
            } catch (e: Exception) {
                runOnUiThread {
                    dlg.dismiss()
                    Toast.makeText(this, "Erro ao importar: ${e.message}", Toast.LENGTH_LONG).show()
                }
            }
        }.start()
    }

    // ---------------------------------------------------------------- carregar e tocar

    private fun openSong(song: Song) {
        root.removeAllViews()
        val status = label("Carregando…", 20f)
        status.gravity = Gravity.CENTER
        root.addView(status, FrameLayout.LayoutParams(MATCH, MATCH))

        Thread {
            try {
                val tracks = SongLoader.load(this, library, song) { done, total ->
                    runOnUiThread { status.text = "Preparando faixas… $done/$total" }
                }
                runOnUiThread {
                    engine.load(tracks)
                    showPlayer(song)
                }
            } catch (e: Exception) {
                val msg = e.cause?.message ?: e.message
                runOnUiThread {
                    Toast.makeText(this, "Erro ao carregar: $msg", Toast.LENGTH_LONG).show()
                    showList()
                }
            }
        }.start()
    }

    private fun leavePlayer() {
        engine.pause()
        showList()
    }

    private fun togglePlay() {
        if (engine.playing) engine.pause() else engine.play()
        updateTransport()
    }

    private fun fmt(frames: Int): String {
        val s = frames / AudioEngine.SAMPLE_RATE
        return String.format("%d:%02d", s / 60, s % 60)
    }

    private fun updateTransport() {
        val playing = engine.playing
        playBtn?.text = if (playing) "⏸  PAUSAR" else "▶  TOCAR"
        playBtn?.background = bg(if (playing) YELLOW else GREEN)
        if (!dragging) {
            val total = engine.totalFrames
            val pos = engine.positionFrames
            seek?.progress = if (total > 0) (pos.toLong() * 1000 / total).toInt() else 0
            timeText?.text = "${fmt(pos)} / ${fmt(total)}"
        }
    }

    private fun showPlayer(song: Song) {
        inPlayer = true
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)
        root.removeAllViews()

        val col = vertical()

        // cabeçalho
        val header = LinearLayout(this)
        header.orientation = LinearLayout.HORIZONTAL
        header.gravity = Gravity.CENTER_VERTICAL
        header.addView(button("←", SURFACE2, Color.WHITE, 20f) { leavePlayer() }, LinearLayout.LayoutParams(dp(56), dp(48)))
        val title = label(song.name, 22f, bold = true)
        title.setPadding(dp(12), 0, 0, 0)
        header.addView(title, lp(0, WRAP, weight = 1f))
        col.addView(header)

        // controles
        val pb = button("▶  TOCAR", GREEN, Color.BLACK, 26f) { togglePlay() }
        playBtn = pb
        val stopB = button("■", SURFACE2, Color.WHITE, 26f) {
            engine.stop()
            updateTransport()
        }
        val row = LinearLayout(this)
        row.orientation = LinearLayout.HORIZONTAL
        row.addView(pb, lp(0, dp(88), weight = 1f))
        val stopLp = LinearLayout.LayoutParams(dp(88), dp(88))
        stopLp.leftMargin = dp(10)
        row.addView(stopB, stopLp)
        col.addView(row, lp(MATCH, WRAP, top = 14))

        // barra de posição
        val sk = SeekBar(this)
        sk.max = 1000
        sk.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) {
                    val target = (engine.totalFrames.toLong() * p / 1000).toInt()
                    timeText?.text = "${fmt(target)} / ${fmt(engine.totalFrames)}"
                }
            }

            override fun onStartTrackingTouch(s: SeekBar) {
                dragging = true
            }

            override fun onStopTrackingTouch(s: SeekBar) {
                engine.seek((engine.totalFrames.toLong() * s.progress / 1000).toInt())
                dragging = false
                updateTransport()
            }
        })
        seek = sk
        col.addView(sk, lp(MATCH, WRAP, top = 12))

        val tt = label("0:00 / 0:00", 14f, MUTED)
        tt.gravity = Gravity.END
        timeText = tt
        col.addView(tt, lp(MATCH, WRAP))

        // saída dividida
        val sw = Switch(this)
        sw.text = "Guia à esquerda, faixas à direita"
        sw.setTextColor(Color.WHITE)
        sw.isChecked = engine.split
        sw.setOnCheckedChangeListener { _, checked -> engine.split = checked }
        col.addView(sw, lp(MATCH, WRAP, top = 8))
        col.addView(
            label("Ligado: o guia sai só no lado esquerdo (fone do músico) e as faixas só no direito (mesa). Desligado: tudo sai junto, em estéreo normal.", 12f, MUTED),
            lp(MATCH, WRAP, top = 4)
        )

        // faixas
        engine.tracks.forEachIndexed { i, t -> col.addView(trackRow(song, i, t), lp(MATCH, WRAP, top = 10)) }

        val scroll = ScrollView(this)
        scroll.addView(col)
        root.addView(scroll, FrameLayout.LayoutParams(MATCH, MATCH))

        ui.removeCallbacks(ticker)
        ui.post(ticker)
    }

    private fun trackRow(song: Song, idx: Int, t: AudioEngine.Track): View {
        val card = LinearLayout(this)
        card.orientation = LinearLayout.VERTICAL
        card.background = bg(SURFACE)
        card.setPadding(dp(12), dp(10), dp(12), dp(10))

        val top = LinearLayout(this)
        top.orientation = LinearLayout.HORIZONTAL
        top.gravity = Gravity.CENTER_VERTICAL
        top.addView(label(t.name, 17f, bold = true), lp(0, WRAP, weight = 1f))

        val roleB = button("", SURFACE2, Color.BLACK, 13f) {}
        val muteB = button("M", SURFACE2, Color.WHITE, 15f) {}
        val soloB = button("S", SURFACE2, Color.WHITE, 15f) {}
        for (b in listOf(roleB, muteB, soloB)) {
            b.minWidth = 0
            b.minHeight = 0
            b.setPadding(0, 0, 0, 0)
        }

        fun refresh() {
            roleB.text = if (t.guide) "GUIA · E" else "FAIXA · D"
            roleB.background = bg(if (t.guide) ORANGE else ACCENT)
            muteB.background = bg(if (t.mute) RED else SURFACE2)
            soloB.background = bg(if (t.solo) YELLOW else SURFACE2)
            soloB.setTextColor(if (t.solo) Color.BLACK else Color.WHITE)
        }
        refresh()

        roleB.setOnClickListener {
            t.guide = !t.guide
            song.tracks[idx].guide = t.guide
            library.save()
            refresh()
        }
        muteB.setOnClickListener {
            t.mute = !t.mute
            refresh()
        }
        soloB.setOnClickListener {
            t.solo = !t.solo
            refresh()
        }

        top.addView(roleB, LinearLayout.LayoutParams(dp(92), dp(44)))
        val mLp = LinearLayout.LayoutParams(dp(44), dp(44))
        mLp.leftMargin = dp(8)
        top.addView(muteB, mLp)
        val sLp = LinearLayout.LayoutParams(dp(44), dp(44))
        sLp.leftMargin = dp(8)
        top.addView(soloB, sLp)
        card.addView(top)

        val vol = SeekBar(this)
        vol.max = 150
        vol.progress = (t.volume * 100).toInt()
        vol.setOnSeekBarChangeListener(object : OnSeekBarChangeListener {
            override fun onProgressChanged(s: SeekBar, p: Int, fromUser: Boolean) {
                if (fromUser) t.volume = p / 100f
            }

            override fun onStartTrackingTouch(s: SeekBar) {}

            override fun onStopTrackingTouch(s: SeekBar) {
                song.tracks[idx].volume = t.volume
                library.save()
            }
        })
        card.addView(vol, lp(MATCH, WRAP, top = 6))
        return card
    }
}
