package com.igreja.multitrack

import android.media.AudioAttributes
import android.media.AudioFormat
import android.media.AudioTrack
import android.os.Process
import java.io.File
import java.io.RandomAccessFile
import java.nio.ByteOrder
import java.nio.ShortBuffer
import java.nio.channels.FileChannel
import java.util.concurrent.atomic.AtomicInteger

/**
 * Motor de áudio: mistura todas as faixas na mesma thread (sincronia por amostra) e grava
 * em um único AudioTrack estéreo.
 *
 * Modo dividido: faixas marcadas como GUIA vão só para o canal ESQUERDO e as demais só para o DIREITO.
 * Modo normal: tudo é somado e sai igual nos dois lados.
 */
class AudioEngine {

    class Track(
        val name: String,
        private val data: ShortBuffer,
        val frames: Int,
        @Volatile var guide: Boolean,
        @Volatile var volume: Float
    ) {
        @Volatile var mute = false
        @Volatile var solo = false

        fun sample(i: Int): Int = data.get(i).toInt()

        companion object {
            fun fromFile(name: String, file: File, guide: Boolean, volume: Float): Track {
                val len = file.length()
                if (len < 2) return Track(name, ShortBuffer.allocate(0), 0, guide, volume)
                RandomAccessFile(file, "r").use { raf ->
                    val mapped = raf.channel.map(FileChannel.MapMode.READ_ONLY, 0, len)
                    val sb = mapped.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                    return Track(name, sb, sb.capacity(), guide, volume)
                }
            }
        }
    }

    companion object {
        const val SAMPLE_RATE = 44100
        const val CHUNK = 512
    }

    @Volatile var tracks: List<Track> = emptyList()
    @Volatile var split = true
    @Volatile var playing = false
    @Volatile private var alive = false

    private val position = AtomicInteger(0)
    private var thread: Thread? = null

    var onEnded: (() -> Unit)? = null

    val totalFrames: Int
        get() = tracks.maxOfOrNull { it.frames } ?: 0

    val positionFrames: Int
        get() = position.get()

    fun load(newTracks: List<Track>) {
        playing = false
        position.set(0)
        tracks = newTracks
        ensureThread()
    }

    fun play() {
        if (tracks.isEmpty()) return
        if (position.get() >= totalFrames) position.set(0)
        playing = true
    }

    fun pause() {
        playing = false
    }

    fun stop() {
        playing = false
        position.set(0)
    }

    fun seek(frames: Int) {
        position.set(frames.coerceIn(0, totalFrames))
    }

    fun release() {
        alive = false
        playing = false
        thread?.join(500)
        thread = null
    }

    private fun ensureThread() {
        if (thread?.isAlive == true) return
        alive = true
        thread = Thread { runLoop() }.also { it.start() }
    }

    private fun clip(v: Float): Short {
        val c = if (v > 32767f) 32767f else if (v < -32768f) -32768f else v
        return c.toInt().toShort()
    }

    private fun runLoop() {
        Process.setThreadPriority(Process.THREAD_PRIORITY_URGENT_AUDIO)

        val minBytes = AudioTrack.getMinBufferSize(
            SAMPLE_RATE, AudioFormat.CHANNEL_OUT_STEREO, AudioFormat.ENCODING_PCM_16BIT
        )
        val at = AudioTrack.Builder()
            .setAudioAttributes(
                AudioAttributes.Builder()
                    .setUsage(AudioAttributes.USAGE_MEDIA)
                    .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC)
                    .build()
            )
            .setAudioFormat(
                AudioFormat.Builder()
                    .setSampleRate(SAMPLE_RATE)
                    .setEncoding(AudioFormat.ENCODING_PCM_16BIT)
                    .setChannelMask(AudioFormat.CHANNEL_OUT_STEREO)
                    .build()
            )
            .setBufferSizeInBytes(maxOf(minBytes, CHUNK * 4 * 4))
            .setTransferMode(AudioTrack.MODE_STREAM)
            .setPerformanceMode(AudioTrack.PERFORMANCE_MODE_LOW_LATENCY)
            .build()
        at.play()

        val out = ShortArray(CHUNK * 2)

        while (alive) {
            if (!playing) {
                Thread.sleep(2)
                continue
            }

            val pos = position.get()
            val ts = tracks
            var total = 0
            for (t in ts) if (t.frames > total) total = t.frames

            if (pos >= total) {
                playing = false
                position.set(0)
                onEnded?.invoke()
                continue
            }

            val n = ts.size
            var anySolo = false
            for (t in ts) if (t.solo) anySolo = true
            val gains = FloatArray(n)
            for (i in 0 until n) {
                val t = ts[i]
                val audible = if (anySolo) t.solo else !t.mute
                gains[i] = if (audible) t.volume else 0f
            }
            val splitMode = split

            for (f in 0 until CHUNK) {
                val p = pos + f
                var l = 0f
                var r = 0f
                for (i in 0 until n) {
                    val g = gains[i]
                    if (g == 0f) continue
                    val t = ts[i]
                    if (p >= t.frames) continue
                    val s = t.sample(p) * g
                    if (t.guide) l += s else r += s
                }
                if (!splitMode) {
                    val m = l + r
                    l = m
                    r = m
                }
                out[f * 2] = clip(l)
                out[f * 2 + 1] = clip(r)
            }

            at.write(out, 0, out.size)
            position.compareAndSet(pos, minOf(pos + CHUNK, total))
        }

        at.stop()
        at.release()
    }
}
