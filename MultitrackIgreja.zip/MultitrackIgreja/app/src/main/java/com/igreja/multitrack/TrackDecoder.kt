package com.igreja.multitrack

import android.media.MediaCodec
import android.media.MediaExtractor
import android.media.MediaFormat
import java.io.File
import java.io.FileOutputStream
import java.nio.ByteOrder

/** Grava amostras PCM 16-bit (little-endian) em arquivo. */
private class PcmSink(file: File) {
    private val os = FileOutputStream(file)
    private val buf = ByteArray(1 shl 16)
    private var n = 0
    var frames = 0

    fun put(v: Int) {
        val s = if (v > 32767) 32767 else if (v < -32768) -32768 else v
        buf[n++] = s.toByte()
        buf[n++] = (s shr 8).toByte()
        frames++
        if (n == buf.size) {
            os.write(buf, 0, n)
            n = 0
        }
    }

    fun close() {
        if (n > 0) os.write(buf, 0, n)
        os.close()
    }
}

/** Reamostragem linear simples (só usada quando o arquivo não está em 44,1 kHz). */
private class Resampler(var ratio: Double, private val sink: PcmSink) {
    private var index = 0L
    private var pos = 0.0
    private var prev = 0

    fun push(s: Int) {
        if (ratio == 1.0) {
            sink.put(s)
            index++
            pos = index.toDouble()
            prev = s
            return
        }
        while (pos <= index) {
            val frac = pos - (index - 1)
            sink.put((prev + (s - prev) * frac).toInt())
            pos += ratio
        }
        prev = s
        index++
    }
}

object TrackDecoder {

    const val OUT_RATE = 44100

    /**
     * Decodifica qualquer áudio (mp3, wav, m4a, ogg, flac...) para PCM mono 16-bit a 44,1 kHz.
     * Todas as faixas ficam com o mesmo formato, o que garante sincronia perfeita entre elas.
     * Retorna o número de frames gravados.
     */
    fun decodeToMono(input: File, output: File): Int {
        val extractor = MediaExtractor()
        extractor.setDataSource(input.absolutePath)

        var trackIndex = -1
        var format: MediaFormat? = null
        for (i in 0 until extractor.trackCount) {
            val f = extractor.getTrackFormat(i)
            val mime = f.getString(MediaFormat.KEY_MIME)
            if (mime != null && mime.startsWith("audio/")) {
                trackIndex = i
                format = f
                break
            }
        }
        if (trackIndex < 0 || format == null) {
            extractor.release()
            throw IllegalArgumentException("Arquivo sem áudio: ${input.name}")
        }
        extractor.selectTrack(trackIndex)

        val codec = MediaCodec.createDecoderByType(format.getString(MediaFormat.KEY_MIME)!!)
        codec.configure(format, null, null, 0)
        codec.start()

        var channels = format.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
        val srcRate = format.getInteger(MediaFormat.KEY_SAMPLE_RATE)

        val tmp = File(output.parentFile, output.name + ".tmp")
        val sink = PcmSink(tmp)
        val resampler = Resampler(srcRate.toDouble() / OUT_RATE, sink)
        val info = MediaCodec.BufferInfo()

        var inputDone = false
        var outputDone = false
        var ok = false
        try {
            while (!outputDone) {
                if (!inputDone) {
                    val inIdx = codec.dequeueInputBuffer(10_000)
                    if (inIdx >= 0) {
                        val inBuf = codec.getInputBuffer(inIdx)!!
                        val size = extractor.readSampleData(inBuf, 0)
                        if (size < 0) {
                            codec.queueInputBuffer(inIdx, 0, 0, 0, MediaCodec.BUFFER_FLAG_END_OF_STREAM)
                            inputDone = true
                        } else {
                            codec.queueInputBuffer(inIdx, 0, size, extractor.sampleTime, 0)
                            extractor.advance()
                        }
                    }
                }

                val outIdx = codec.dequeueOutputBuffer(info, 10_000)
                if (outIdx >= 0) {
                    val outBuf = codec.getOutputBuffer(outIdx)!!
                    if (info.size > 0) {
                        outBuf.position(info.offset)
                        outBuf.limit(info.offset + info.size)
                        val shorts = outBuf.order(ByteOrder.LITTLE_ENDIAN).asShortBuffer()
                        val ch = if (channels < 1) 1 else channels
                        val frames = shorts.remaining() / ch
                        for (f in 0 until frames) {
                            var sum = 0
                            for (c in 0 until ch) sum += shorts.get().toInt()
                            resampler.push(sum / ch)
                        }
                    }
                    codec.releaseOutputBuffer(outIdx, false)
                    if ((info.flags and MediaCodec.BUFFER_FLAG_END_OF_STREAM) != 0) outputDone = true
                } else if (outIdx == MediaCodec.INFO_OUTPUT_FORMAT_CHANGED) {
                    val nf = codec.outputFormat
                    channels = nf.getInteger(MediaFormat.KEY_CHANNEL_COUNT)
                    resampler.ratio = nf.getInteger(MediaFormat.KEY_SAMPLE_RATE).toDouble() / OUT_RATE
                }
            }
            ok = true
        } finally {
            try {
                codec.stop()
            } catch (e: Exception) {
            }
            codec.release()
            extractor.release()
            sink.close()
            if (!ok) tmp.delete()
        }

        if (output.exists()) output.delete()
        if (!tmp.renameTo(output)) throw IllegalStateException("Não foi possível gravar ${output.name}")
        return sink.frames
    }
}
