# Multitrack Igreja

App Android para disparar multitracks (stems) na igreja.

## O que ele faz

- Importa os arquivos de uma música (mp3, wav, m4a, ogg, flac) de uma vez.
- Toca todas as faixas **sincronizadas por amostra** (todas são decodificadas para o mesmo formato).
- **Guia/click só no canal esquerdo e faixas só no direito**, para separar fone do músico e mesa.
  Faixas com nome contendo "click", "guia", "guide", "cue" ou "metro" já entram como GUIA automaticamente.
  Toque no botão **GUIA · E / FAIXA · D** de cada faixa para trocar.
- Volume, **M** (mudo) e **S** (solo) por faixa; barra de posição; botão de tocar/pausar grande.
- Tela fica acesa enquanto você está na tela da música.

## Como usar

1. Abra o app e toque em **Nova música**.
2. Digite o nome e escolha **todos os arquivos** dela de uma vez.
3. Toque na música. Na primeira vez ela é preparada (alguns segundos); nas próximas fica mais rápido.
4. Para o canal separado funcionar, use uma saída estéreo (cabo P2 estéreo, Y para 2 canais, ou interface USB com 2 saídas):
   esquerdo = guia, direito = faixas.

## Como gerar o APK

### Opção A: GitHub (não instala nada)

1. Crie uma conta em github.com e um repositório novo (pode ser privado).
2. Envie **todo o conteúdo desta pasta** (incluindo a pasta oculta `.github`) para o repositório.
3. Abra a aba **Actions**, escolha **Gerar APK** e, se não começar sozinho, toque em **Run workflow**.
4. Quando terminar (uns 3 a 6 minutos), abra a execução e baixe **MultitrackIgreja-APK** em *Artifacts*.
   Dentro do zip está o arquivo `.apk`.

### Opção B: Android Studio

1. Abra o Android Studio e escolha **Open** nesta pasta.
2. Espere a sincronização terminar.
3. Menu **Build > Build Bundle(s) / APK(s) > Build APK(s)**.

## Instalar no celular

Passe o `.apk` para o celular, abra o arquivo e permita "Instalar apps desconhecidos" quando o Android pedir.

## Limites desta versão

- Se o app for para segundo plano por muito tempo, o Android pode pausar o áudio. Mantenha-o aberto.
- Sem fila de músicas (setlist) automática nem pitch/tempo ainda.
